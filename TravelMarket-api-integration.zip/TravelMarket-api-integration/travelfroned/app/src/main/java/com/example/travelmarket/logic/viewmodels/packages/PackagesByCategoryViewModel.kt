package com.example.travelmarket.logic.viewmodels.packages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.travelmarket.core.network.NetworkResult
import com.example.travelmarket.logic.domain.models.Package
import com.example.travelmarket.logic.domain.usecases.packages.GetPackagesByCategoryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PackagesByCategoryViewModel @Inject constructor(
    private val getPackagesByCategoryUseCase: GetPackagesByCategoryUseCase
) : ViewModel() {

    private val _packages = MutableStateFlow<List<Package>>(emptyList())
    val packages: StateFlow<List<Package>> = _packages

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun loadPackagesByCategory(categoryId: Long) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            when (val result = getPackagesByCategoryUseCase(categoryId)) {
                is NetworkResult.Success -> {
                    _packages.value = result.data
                    _error.value = null
                }
                is NetworkResult.Error -> {
                    _error.value = result.message as? String ?: "Error al cargar paquetes"
                }
                is NetworkResult.Loading -> {
                    _loading.value = true
                }
            }
            _loading.value = false
        }
    }
}

