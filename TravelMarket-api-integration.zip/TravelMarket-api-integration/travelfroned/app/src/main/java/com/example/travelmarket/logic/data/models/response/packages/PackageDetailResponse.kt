package com.example.travelmarket.logic.data.models.response.packages

import com.google.gson.annotations.SerializedName

data class PackageDetailResponse(
    @SerializedName("exito") val exito: Boolean?,
    @SerializedName("mensaje") val mensaje: String?,
    @SerializedName("paquete") val paquete: PackageResponse?
)

