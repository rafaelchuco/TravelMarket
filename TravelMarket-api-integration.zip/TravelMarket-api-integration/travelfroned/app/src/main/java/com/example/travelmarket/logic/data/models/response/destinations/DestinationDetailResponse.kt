package com.example.travelmarket.logic.data.models.response.destinations

import com.google.gson.annotations.SerializedName

data class DestinationDetailResponse(
    @SerializedName("exito") val exito: Boolean?,
    @SerializedName("mensaje") val mensaje: String?,
    @SerializedName("destino") val destino: DestinationResponse?
)

