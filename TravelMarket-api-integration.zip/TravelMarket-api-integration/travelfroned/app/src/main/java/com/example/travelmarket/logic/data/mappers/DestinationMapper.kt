package com.example.travelmarket.logic.data.mappers

import com.example.travelmarket.logic.data.models.response.destinations.DestinationResponse
import com.example.travelmarket.logic.domain.models.Destination

object DestinationMapper {
    fun toDomain(response: DestinationResponse): Destination {
        if (response.id == null) {
            throw IllegalArgumentException("Destination ID is required but was null")
        }
        
        // Convertir latitude y longitude a String
        val latitudeStr = when (response.latitude) {
            is String -> response.latitude
            is Number -> response.latitude.toString()
            null -> ""
            else -> response.latitude.toString()
        }
        
        val longitudeStr = when (response.longitude) {
            is String -> response.longitude
            is Number -> response.longitude.toString()
            null -> ""
            else -> response.longitude.toString()
        }
        
        return Destination(
            id = response.id,
            name = response.name ?: "Sin nombre",  // ✅ AGREGADO ?: "Sin nombre"
            country = response.country ?: "",  // ✅ AGREGADO ?: ""
            continent = response.continent ?: "",
            description = response.description ?: "",
            shortDescription = response.shortDescription ?: "",
            latitude = latitudeStr,
            longitude = longitudeStr,
            imageUrl = response.image ?: "",
            isPopular = response.isPopular ?: false,
            bestSeason = response.bestSeason ?: "",
            createdAt = response.createdAt ?: ""
        )
    }

    fun toDomainList(responses: List<DestinationResponse>): List<Destination> {
        return responses.map { toDomain(it) }
    }
}
