package com.example.travelmarket.core.di

import com.example.travelmarket.logic.domain.usecases.destinations.GetDestinationByIdUseCase
import com.example.travelmarket.logic.domain.usecases.destinations.GetDestinationsUseCase
import com.example.travelmarket.logic.domain.usecases.flights.GetFlightByIdUseCase
import com.example.travelmarket.logic.domain.usecases.flights.GetFlightsUseCase
import com.example.travelmarket.logic.domain.usecases.packages.GetPackageByIdUseCase
import com.example.travelmarket.logic.domain.usecases.packages.GetPackagesByCategoryUseCase
import com.example.travelmarket.logic.domain.usecases.packages.GetPackagesUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    // ========== DESTINATIONS ==========
    @Provides
    @Singleton
    fun provideGetDestinationsUseCase(
        destinationsRepository: com.example.travelmarket.logic.domain.repositories.DestinationsRepository
    ): GetDestinationsUseCase {
        return GetDestinationsUseCase(destinationsRepository)
    }

    @Provides
    @Singleton
    fun provideGetDestinationByIdUseCase(
        destinationsRepository: com.example.travelmarket.logic.domain.repositories.DestinationsRepository
    ): GetDestinationByIdUseCase {
        return GetDestinationByIdUseCase(destinationsRepository)
    }

    // ========== FLIGHTS ==========
    @Provides
    @Singleton
    fun provideGetFlightsUseCase(
        flightsRepository: com.example.travelmarket.logic.domain.repositories.FlightsRepository
    ): GetFlightsUseCase {
        return GetFlightsUseCase(flightsRepository)
    }

    @Provides
    @Singleton
    fun provideGetFlightByIdUseCase(
        flightsRepository: com.example.travelmarket.logic.domain.repositories.FlightsRepository
    ): GetFlightByIdUseCase {
        return GetFlightByIdUseCase(flightsRepository)
    }

    // ========== PACKAGES ==========
    @Provides
    @Singleton
    fun provideGetPackagesUseCase(
        packagesRepository: com.example.travelmarket.logic.domain.repositories.PackagesRepository
    ): GetPackagesUseCase {
        return GetPackagesUseCase(packagesRepository)
    }

    @Provides
    @Singleton
    fun provideGetPackageByIdUseCase(
        packagesRepository: com.example.travelmarket.logic.domain.repositories.PackagesRepository
    ): GetPackageByIdUseCase {
        return GetPackageByIdUseCase(packagesRepository)
    }

    @Provides
    @Singleton
    fun provideGetPackagesByCategoryUseCase(
        packagesRepository: com.example.travelmarket.logic.domain.repositories.PackagesRepository
    ): GetPackagesByCategoryUseCase {
        return GetPackagesByCategoryUseCase(packagesRepository)
    }
}

